=== Human Bmi Bmr Calculation ===
Contributors: khalifalmahmud
Donate link: #
Tags: Bmi,Bmr,Calculation
Requires at least: 4.0
Tested up to: 5.1
Requires PHP: 5.2.4
Stable tag: 4.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Human Bmi Bmr Calculation Plugin.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/amp-for-contact-form-7` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png

== Changelog ==

= 1.0 =
* First Version Of This Plugin

== Upgrade Notice ==

= 1.0 =
First Version Of This Plugin
