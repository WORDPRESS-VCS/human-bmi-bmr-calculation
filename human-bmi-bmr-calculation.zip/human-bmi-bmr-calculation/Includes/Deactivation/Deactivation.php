<?php

namespace Hbmibmrc\Deactivation;

class Deactivation
{
    public function __construct()
    {
    }
}
